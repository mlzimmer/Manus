/*
Copyright 2016 Manus VR
*/

#pragma once

#include "Manus.h"

uint32_t ManusUpdateIKInternal(manus_session_t session, ik_body_t* model);